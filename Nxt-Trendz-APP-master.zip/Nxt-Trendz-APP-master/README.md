# Ecommerce Application - Final Code - After React Context Part | 4

- Empty Cart View
- Displaying Cart Items Count

## Need to Add Features on our own from now on
1) Delete Cart Item - If a user clicks on the delete button, the Cart Item should be removed from the CartList
2) Cart Summary -- at the bottom left corner -- Display the total amount and number of items in the cart in the Cart Route
3) Update Quantity -- User should be able to update the quantity in the cart
4) Updating Quantity on adding same Product -- If a user tries to add the same item for the next time, the quantity of an item should be updated.
5) Add Remove All button -- Remove all cart items at once
  
### Deployment

- ccbp start RJSIVPP7N7

- ccbp publish RJSIVPP7N7 nnrnxttrendz.ccbp.tech

- Website URL =  https://nnrnxttrendz.ccbp.tech/
